# Copyright (c) 2025, Dharmesh Rathod and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestBlockSelection(FrappeTestCase):
	pass
