# Copyright (c) 2025, Ayush Patel and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document


class SizeListVerification(Document):
	pass


@frappe.whitelist()
def get_size_list_with_details(size_list_name):
	"""
	Fetch Size List document with all its child table details
	This method runs with elevated permissions to avoid permission issues
	"""
	try:
		# Get the main Size List document
		size_list = frappe.get_doc("Size List", size_list_name)
		
		# Get all Size List Details for this Size List
		stone_details = frappe.get_all(
			"Size List Details",
			filters={"parent": size_list_name},
			fields=["*"]
		)
		
		# Convert to dict and add stone_details
		size_list_dict = size_list.as_dict()
		size_list_dict["stone_details"] = stone_details
		
		return {
			"success": True,
			"message": "Size List data fetched successfully",
			"data": size_list_dict
		}
		
	except frappe.DoesNotExistError:
		return {
			"success": False,
			"message": f"Size List {size_list_name} not found"
		}
	except Exception as e:
		frappe.log_error(f"Error fetching Size List {size_list_name}: {str(e)}")
		return {
			"success": False,
			"message": f"Error fetching Size List: {str(e)}"
		}


@frappe.whitelist()
def search_size_list_by_form_number(form_number):
	"""
	Search for Size List by form_number field and return with details
	"""
	try:
		# Search for Size List with matching form_number
		size_lists = frappe.get_all(
			"Size List",
			filters={"form_number": form_number},
			fields=["name"],
			limit=1
		)
		
		if not size_lists:
			return {
				"success": False,
				"message": f"No Size List found with Form Number: {form_number}"
			}
		
		# Get the full Size List data using the first method
		return get_size_list_with_details(size_lists[0].name)
		
	except Exception as e:
		frappe.log_error(f"Error searching Size List by form number {form_number}: {str(e)}")
		return {
			"success": False,
			"message": f"Error searching Size List: {str(e)}"
		}


@frappe.whitelist()
def get_verified_stones_for_generation(form_number):
	"""
	Get only verified stone details from Size List Verification for Size List Generation
	"""
	try:
		verification_doc = None
		original_form_number = None
		
		# Check if the input is a Size List Verification document name (SZVER-xxxx)
		if form_number.startswith("SZVER-"):
			# Direct lookup by Size List Verification document name
			try:
				verification_doc = frappe.get_doc("Size List Verification", form_number)
				original_form_number = verification_doc.form_number
			except frappe.DoesNotExistError:
				pass
		
		# If not found above, try to find by form_number field (original Size List number)
		if not verification_doc:
			verifications = frappe.get_all(
				"Size List Verification",
				filters={"form_number": form_number},
				fields=["name", "form_number"],
				limit=1
			)
			
			if verifications:
				verification_doc = frappe.get_doc("Size List Verification", verifications[0].name)
				original_form_number = form_number
		
		if not verification_doc:
			return {
				"success": False,
				"message": f"No Size List Verification found for: {form_number}"
			}
		
		# Get the original Size List data first
		size_list = frappe.get_doc("Size List", original_form_number)
		
		# Get verified stone details from verification
		verified_stones = []
		if verification_doc.stone_details:
			frappe.logger().debug(f"DEBUG: Found {len(verification_doc.stone_details)} stones in verification doc")
			for i, stone in enumerate(verification_doc.stone_details):
				verified_value = getattr(stone, 'verified', 0)
				frappe.logger().debug(f"DEBUG: Stone {i+1}: {stone.stone_name}, verified = {verified_value}")
				# Only include stones that are marked as verified (verified checkbox = 1)
				if verified_value == 1:
					verified_stones.append({
						"stone_name": stone.stone_name,
						"stone_code": stone.stone_code,
						"range": stone.range,
						"l1": stone.l1,
						"l2": stone.l2,
						"b1": stone.b1,
						"b2": stone.b2,
						"h1": stone.h1,
						"h2": stone.h2,
						"volume": stone.volume
					})
		
		# Prepare response with Size List data and only verified stones
		size_list_dict = size_list.as_dict()
		size_list_dict["stone_details"] = verified_stones
		
		return {
			"success": True,
			"message": f"Found {len(verified_stones)} verified stones out of {len(verification_doc.stone_details or [])} total stones",
			"data": size_list_dict,
			"verification_stats": {
				"total_stones": len(verification_doc.stone_details or []),
				"verified_stones": len(verified_stones),
				"pending_stones": len(verification_doc.stone_details or []) - len(verified_stones)
			}
		}
		
	except frappe.DoesNotExistError:
		return {
			"success": False,
			"message": f"Size List {form_number} not found"
		}
	except Exception as e:
		frappe.log_error(f"Error getting verified stones for {form_number}: {str(e)}")
		return {
			"success": False,
			"message": f"Error getting verified stones: {str(e)}"
		}

@frappe.whitelist()
def debug_verification_stones(form_number):
	"""Debug method to check verification stone data"""
	try:
		verification_doc = frappe.get_doc("Size List Verification", form_number)
		debug_info = {
			"doc_name": verification_doc.name,
			"form_number": verification_doc.form_number,
			"stone_details_count": len(verification_doc.stone_details or []),
			"stones": []
		}
		
		if verification_doc.stone_details:
			for stone in verification_doc.stone_details:
				stone_info = {
					"name": stone.name,
					"stone_name": stone.stone_name,
					"stone_code": stone.stone_code,
					"verified": getattr(stone, 'verified', 'NOT_FOUND'),
					"verified_type": type(getattr(stone, 'verified', None))._name_
				}
				debug_info["stones"].append(stone_info)
		
		return debug_info
		
	except Exception as e:
		return {"error": str(e)}