# Copyright (c) 2025, Ayush Patel and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestLoanApplication(FrappeTestCase):
	pass
