// Copyright (c) 2025, Amax Consultancy Pvt Ltd and contributors
// For license information, please see license.txt

// frappe.ui.form.on("SIze List Generation", {
// 	refresh(frm) {

// 	},
// });



frappe.ui.form.on('SIze List Generation', {
    form_number: function(frm) {
        if (!frm.doc.form_number) return;

        frappe.call({
            method: "baps.baps.doctype.size_list_verification.size_list_verification.move_verified_to_generation",
            args: { verification_name: frm.doc.form_number },
            callback: function(r) {
                frappe.msgprint("✅ Verified rows fetched to Generation");
                frm.reload_doc(); // refresh to show rows
            }
        });
    }
});
