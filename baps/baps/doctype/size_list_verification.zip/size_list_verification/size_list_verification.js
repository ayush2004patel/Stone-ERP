// Copyright (c) 2025, Ayush Patel and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Size List Verification", {
// 	refresh(frm) {

// 	},
// });
