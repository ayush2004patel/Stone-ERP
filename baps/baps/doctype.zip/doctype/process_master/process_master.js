// Copyright (c) 2025, Ayush Patel and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Process Master", {
// 	refresh(frm) {

// 	},
// });
