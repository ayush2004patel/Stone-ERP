// // ============================
// // Child Doctype: Size List Details
// // ============================
// frappe.ui.form.on('Size List Details', {
//     // --- Range -> auto create rows ---
//     range: function(frm, cdt, cdn) {
//         if (frm.__range_generating) return;

//         let row = locals[cdt][cdn];
//         let input = (row.range || '').toString().trim();

//         let m = input.match(/^(\d+)\s*[-–]\s*(\d+)$/);
//         if (!m) return;

//         let start = parseInt(m[1], 10);
//         let end   = parseInt(m[2], 10);
//         if (isNaN(start) || isNaN(end) || start > end) return;

//         const width = Math.max(m[1].length, m[2].length);

//         // Save template row values (the first row user filled)
//         let template = Object.assign({}, row);

//         frm.__range_generating = true;
//         setTimeout(() => {
//             frm.clear_table('stone_details');

//             for (let i = start; i <= end; i++) {
//                 let r = frm.add_child('stone_details');

//                 // Copy all fields from template row
//                 Object.keys(template).forEach(f => {
//                     if (f !== "name" && f !== "idx" && f !== "doctype") {
//                         r[f] = template[f];
//                     }
//                 });

//                 // Update range
//                 r.range = i.toString().padStart(width, '0');

//                 // Auto increment stone code if format matches (prefix + digits)
//                 if (template.stone_code) {
//                     let codeMatch = template.stone_code.match(/^(\D*)(\d+)$/); 
//                     if (codeMatch) {
//                         let prefix = codeMatch[1];
//                         let num = parseInt(codeMatch[2], 10);
//                         let numWidth = codeMatch[2].length;
//                         r.stone_code = prefix + (num + (i - start)).toString().padStart(numWidth, '0');
//                     }
//                 }

//                 // Copy same dimensions for all rows
//                 r.l1 = template.l1;
//                 r.l2 = template.l2;
//                 r.b1 = template.b1;
//                 r.b2 = template.b2;
//                 r.h1 = template.h1;
//                 r.h2 = template.h2;

//                 // Recalculate volume for each row
//                 calculate_volume(frm, r.doctype, r.name);
//             }

//             frm.refresh_field('stone_details');
//             frm.__range_generating = false;
//             update_total_volume(frm);
//         }, 0);
//     },

//     // --- Dimension fields with inch validation (< 12) ---
//     l1: calculate_volume,
//     l2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.l2 >= 12) {
//             frappe.msgprint(('L2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'l2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     b1: calculate_volume,
//     b2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.b2 >= 12) {
//             frappe.msgprint(('B2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'b2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     h1: calculate_volume,
//     h2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.h2 >= 12) {
//             frappe.msgprint(('H2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'h2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },

//     stone_details_remove: function(frm) {
//         update_total_volume(frm);
//     },

//     // --- Chemical / Dry Fitting controlled by Baps Project ---
//     chemical: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm.doc.project_chemical) {
//             row.chemical = 1;
//             frm.refresh_field("stone_details");
//             frappe.msgprint(("Chemical is controlled by Baps Project and cannot be changed."));
//         }
//     },
//     dry_fitting: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm.doc.project_dry_fitting) {
//             row.dry_fitting = 1;
//             frm.refresh_field("stone_details");
//             frappe.msgprint(("Dry Fitting is controlled by Baps Project and cannot be changed."));
//         }
//     }
// });

// // --- Volume calculation for a single row ---
// function calculate_volume(frm, cdt, cdn) {
//     let row = locals[cdt][cdn];

//     // Convert feet+inches → inches
//     let L = ((row.l1 || 0) * 12) + (row.l2 || 0);
//     let B = ((row.b1 || 0) * 12) + (row.b2 || 0);
//     let H = ((row.h1 || 0) * 12) + (row.h2 || 0);

//     // Volume in cubic feet
//     row.volume = ((L * B * H) / 1728).toFixed(2);

//     frm.refresh_field('stone_details');
//     update_total_volume(frm);
// }

// // --- Total volume across all rows ---
// function update_total_volume(frm) {
//     let total = 0;
//     (frm.doc.stone_details || []).forEach(r => {
//         total += flt(r.volume);
//     });
//     frm.set_value('total_volume', total.toFixed(2));
// }

// // ============================
// // Parent Doctype: Size List
// // ============================
// frappe.ui.form.on('Size List', {
//     main_part: function(frm) {
//         if (!frm.doc.main_part) {
//             frm.set_value('sub_part', '');
//         }
//     },
//     sub_part: function(frm) {
//         if (!frm.doc.sub_part) {
//             frm.set_value('main_part', '');
//         }
//     },
//     refresh: function(frm) {
//         apply_project_checkboxes(frm);
//     },
//     baps_project: function(frm) {
//         if (frm.doc.baps_project) {
//             frappe.db.get_doc("Baps Project", frm.doc.baps_project).then(project => {
//                 frm.doc.project_chemical = project.chemical;
//                 frm.doc.project_dry_fitting = project.dry_fitting;
//                 apply_project_checkboxes(frm);
//             });
//         } else {
//             frm.doc.project_chemical = 0;
//             frm.doc.project_dry_fitting = 0;
//             apply_project_checkboxes(frm);
//         }
//     }
// });

// // --- Apply project checkboxes to all child rows ---
// function apply_project_checkboxes(frm) {
//     (frm.doc.stone_details || []).forEach(row => {
//         if (frm.doc.project_chemical) {
//             row.chemical = 1;
//         }
//         if (frm.doc.project_dry_fitting) {
//             row.dry_fitting = 1;
//         }
//     });
//     frm.refresh_field("stone_details");
// }














//       frappe.ui.form.on('Size List Details', {
//     // --- Range -> auto create rows ---
//     range: function(frm, cdt, cdn) {
//         if (frm.__range_generating) return;

//         let row = locals[cdt][cdn];
//         let input = (row.range || '').toString().trim();

//         let m = input.match(/^(\d+)\s*[-–]\s*(\d+)$/);
//         if (!m) return;

//         let start = parseInt(m[1], 10);
//         let end   = parseInt(m[2], 10);
//         if (isNaN(start) || isNaN(end) || start > end) return;

//         const width = Math.max(m[1].length, m[2].length);

//         // Save template row values (the first row user filled)
//         let template = Object.assign({}, row);

//         frm.__range_generating = true;
//         setTimeout(() => {
//             frm.clear_table('stone_details');

//             for (let i = start; i <= end; i++) {
//                 let r = frm.add_child('stone_details');

//                 // Copy all fields from template row
//                 Object.keys(template).forEach(f => {
//                     if (f !== "name" && f !== "idx" && f !== "doctype") {
//                         r[f] = template[f];
//                     }
//                 });

//                 // Update range
//                 r.range = i.toString().padStart(width, '0');

//                 // Auto increment stone code if format matches (prefix + digits)
//                 if (template.stone_code) {
//                     let codeMatch = template.stone_code.match(/^(\D*)(\d+)$/); 
//                     if (codeMatch) {
//                         let prefix = codeMatch[1];
//                         let num = parseInt(codeMatch[2], 10);
//                         let numWidth = codeMatch[2].length;
//                         r.stone_code = prefix + (num + (i - start)).toString().padStart(numWidth, '0');
//                     }
//                 }

//                 // Copy same dimensions for all rows
//                 r.l1 = template.l1;
//                 r.l2 = template.l2;
//                 r.b1 = template.b1;
//                 r.b2 = template.b2;
//                 r.h1 = template.h1;
//                 r.h2 = template.h2;

//                 // Recalculate volume for each row
//                 calculate_volume(frm, r.doctype, r.name);

//                 // --- Apply Baps Project controlled checkboxes ---
//                 if (frm._project_flags?.chemical) r.chemical = 1;
//                 if (frm._project_flags?.dry_fitting) r.dry_fitting = 1;
//             }

//             frm.refresh_field('stone_details');
//             frm.__range_generating = false;
//             update_total_volume(frm);
//         }, 0);
//     },

//     // --- Dimension fields with inch validation (< 12) ---
//     l1: calculate_volume,
//     l2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.l2 >= 12) {
//             frappe.msgprint(('L2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'l2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     b1: calculate_volume,
//     b2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.b2 >= 12) {
//             frappe.msgprint(('B2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'b2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     h1: calculate_volume,
//     h2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.h2 >= 12) {
//             frappe.msgprint(('H2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'h2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },

//     stone_details_remove: function(frm) {
//         update_total_volume(frm);
//     },

//     // --- Chemical / Dry Fitting controlled by Baps Project ---
//     chemical: function(frm, cdt, cdn) {
//         if (frm._project_flags?.chemical) {
//             frappe.model.set_value(cdt, cdn, 'chemical', 1);
//             frappe.msgprint(("Chemical is controlled by the selected Baps Project and cannot be changed."));
//         }
//     },
//     dry_fitting: function(frm, cdt, cdn) {
//         if (frm._project_flags?.dry_fitting) {
//             frappe.model.set_value(cdt, cdn, 'dry_fitting', 1);
//             frappe.msgprint(("Dry Fitting is controlled by the selected Baps Project and cannot be changed."));
//         }
//     },

//     refresh: function(frm) {
//         if (frm && frm.fields_dict && frm.fields_dict.stone_details) {
//             let grid = frm.fields_dict.stone_details.grid;
//             let chem_ro = frm._project_flags?.chemical ? 1 : 0;
//             let dry_ro = frm._project_flags?.dry_fitting ? 1 : 0;
//             grid.update_docfield_property('chemical', 'read_only', chem_ro);
//             grid.update_docfield_property('dry_fitting', 'read_only', dry_ro);
//         }
//     }
// });

// // --- Volume calculation for a single row ---
// function calculate_volume(frm, cdt, cdn) {
//     let row = locals[cdt][cdn];
//     let L = ((row.l1 || 0) * 12) + (row.l2 || 0);
//     let B = ((row.b1 || 0) * 12) + (row.b2 || 0);
//     let H = ((row.h1 || 0) * 12) + (row.h2 || 0);
//     row.volume = ((L * B * H) / 1728).toFixed(2);
//     frm.refresh_field('stone_details');
//     update_total_volume(frm);
// }

// // --- Total volume across all rows ---
// function update_total_volume(frm) {
//     let total = 0;
//     (frm.doc.stone_details || []).forEach(r => {
//         total += flt(r.volume);
//     });
//     frm.set_value('total_volume', total.toFixed(2));
// }

// // --- Helper: set child grid checkboxes read-only based on project flags ---
// function set_child_grid_readonly(frm) {
//     if (!frm.fields_dict || !frm.fields_dict.stone_details) return;
//     let grid = frm.fields_dict.stone_details.grid;
//     let chem_ro = frm._project_flags?.chemical ? 1 : 0;
//     let dry_ro = frm._project_flags?.dry_fitting ? 1 : 0;
//     grid.update_docfield_property('chemical', 'read_only', chem_ro);
//     grid.update_docfield_property('dry_fitting', 'read_only', dry_ro);
// }

// // ============================
// // Parent Doctype: Size List
// // ============================
// frappe.ui.form.on('Size List', {
//     main_part: function(frm) {
//         if (!frm.doc.main_part) frm.set_value('sub_part', '');
//     },
//     sub_part: function(frm) {
//         if (!frm.doc.sub_part) frm.set_value('main_part', '');
//     },
//     refresh: function(frm) {
//         if (frm.doc.baps_project) {
//             load_project_flags(frm);
//         }
//     },
//     baps_project: function(frm) {
//         if (frm.doc.baps_project) {
//             load_project_flags(frm);
//         } else {
//             frm._project_flags = { chemical: 0, dry_fitting: 0 };
//             set_child_grid_readonly(frm);
//         }
//     },
//     stone_details_add: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm._project_flags?.chemical) {
//             frappe.model.set_value(cdt, cdn, 'chemical', 1);
//         }
//         if (frm._project_flags?.dry_fitting) {
//             frappe.model.set_value(cdt, cdn, 'dry_fitting', 1);
//         }
//     }
// });

// // --- Load project flags from linked Baps Project ---
// function load_project_flags(frm) {
//     frappe.db.get_doc("Baps Project", frm.doc.baps_project).then(project => {
//         frm._project_flags = {
//             chemical: project.chemical ? 1 : 0,
//             dry_fitting: project.dry_fitting ? 1 : 0
//         };
//         apply_project_checkboxes(frm);
//         set_child_grid_readonly(frm);
//     });
// }

// // --- Apply project checkboxes to all child rows ---
// function apply_project_checkboxes(frm) {
//     (frm.doc.stone_details || []).forEach(row => {
//         if (frm._project_flags?.chemical) {
//             row.chemical = 1;   // set directly
//             frappe.model.set_value(row.doctype, row.name, 'chemical', 1);
//         }
//         if (frm._project_flags?.dry_fitting) {
//             row.dry_fitting = 1;  // set directly
//             frappe.model.set_value(row.doctype, row.name, 'dry_fitting', 1);
//         }
//     });
//     frm.refresh_field("stone_details");
// }



















// // ============================
// // Child Doctype: Size List Details
// // ============================
// frappe.ui.form.on('Size List Details', {
//     // --- Range -> auto create rows ---
//     range: function(frm, cdt, cdn) {
//         if (frm.__range_generating) return;

//         let row = locals[cdt][cdn];
//         let input = (row.range || '').toString().trim();

//         let m = input.match(/^(\d+)\s*[-–]\s*(\d+)$/);
//         if (!m) return;

//         let start = parseInt(m[1], 10);
//         let end   = parseInt(m[2], 10);
//         if (isNaN(start) || isNaN(end) || start > end) return;

//         const width = Math.max(m[1].length, m[2].length);

//         // Save template row values (the first row user filled)
//         let template = Object.assign({}, row);

//         frm.__range_generating = true;
//         setTimeout(() => {
//             frm.clear_table('stone_details');

//             for (let i = start; i <= end; i++) {
//                 let r = frm.add_child('stone_details');

//                 // Copy all fields from template row
//                 Object.keys(template).forEach(f => {
//                     if (f !== "name" && f !== "idx" && f !== "doctype") {
//                         r[f] = template[f];
//                     }
//                 });

//                 // Update range
//                 r.range = i.toString().padStart(width, '0');

//                 // Auto increment stone code if format matches (prefix + digits)
//                 if (template.stone_code) {
//                     let codeMatch = template.stone_code.match(/^(\D*)(\d+)$/); 
//                     if (codeMatch) {
//                         let prefix = codeMatch[1];
//                         let num = parseInt(codeMatch[2], 10);
//                         let numWidth = codeMatch[2].length;
//                         r.stone_code = prefix + (num + (i - start)).toString().padStart(numWidth, '0');
//                     }
//                 }

//                 // Copy same dimensions for all rows
//                 r.l1 = template.l1;
//                 r.l2 = template.l2;
//                 r.b1 = template.b1;
//                 r.b2 = template.b2;
//                 r.h1 = template.h1;
//                 r.h2 = template.h2;

//                 // Recalculate volume for each row
//                 calculate_volume(frm, r.doctype, r.name);
//             }

//             frm.refresh_field('stone_details');
//             frm.__range_generating = false;
//             update_total_volume(frm);
//         }, 0);
//     },

//     // --- Dimension fields with inch validation (< 12) ---
//     l1: calculate_volume,
//     l2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.l2 >= 12) {
//             frappe.msgprint(('L2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'l2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     b1: calculate_volume,
//     b2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.b2 >= 12) {
//             frappe.msgprint(('B2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'b2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     h1: calculate_volume,
//     h2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.h2 >= 12) {
//             frappe.msgprint(('H2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'h2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },

//     stone_details_remove: function(frm) {
//         update_total_volume(frm);
//     },

//     // --- Chemical / Dry Fitting controlled by Baps Project ---
//     chemical: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm.doc.project_chemical) {
//             row.chemical = 1;
//             frm.refresh_field("stone_details");
//             frappe.msgprint(("Chemical is controlled by Baps Project and cannot be changed."));
//         }
//     },
//     dry_fitting: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm.doc.project_dry_fitting) {
//             row.dry_fitting = 1;
//             frm.refresh_field("stone_details");
//             frappe.msgprint(("Dry Fitting is controlled by Baps Project and cannot be changed."));
//         }
//     }
// });

// // --- Volume calculation for a single row ---
// function calculate_volume(frm, cdt, cdn) {
//     let row = locals[cdt][cdn];

//     // Convert feet+inches → inches
//     let L = ((row.l1 || 0) * 12) + (row.l2 || 0);
//     let B = ((row.b1 || 0) * 12) + (row.b2 || 0);
//     let H = ((row.h1 || 0) * 12) + (row.h2 || 0);

//     // Volume in cubic feet
//     row.volume = ((L * B * H) / 1728).toFixed(2);

//     frm.refresh_field('stone_details');
//     update_total_volume(frm);
// }

// // --- Total volume across all rows ---
// function update_total_volume(frm) {
//     let total = 0;
//     (frm.doc.stone_details || []).forEach(r => {
//         total += flt(r.volume);
//     });
//     frm.set_value('total_volume', total.toFixed(2));
// }

// // ============================
// // Parent Doctype: Size List
// // ============================
// frappe.ui.form.on('Size List', {
//     main_part: function(frm) {
//         if (!frm.doc.main_part) {
//             frm.set_value('sub_part', '');
//         }
//     },
//     sub_part: function(frm) {
//         if (!frm.doc.sub_part) {
//             frm.set_value('main_part', '');
//         }
//     },
//     refresh: function(frm) {
//         apply_project_checkboxes(frm);
//     },
//     baps_project: function(frm) {
//         if (frm.doc.baps_project) {
//             frappe.db.get_doc("Baps Project", frm.doc.baps_project).then(project => {
//                 frm.doc.project_chemical = project.chemical;
//                 frm.doc.project_dry_fitting = project.dry_fitting;
//                 apply_project_checkboxes(frm);
//             });
//         } else {
//             frm.doc.project_chemical = 0;
//             frm.doc.project_dry_fitting = 0;
//             apply_project_checkboxes(frm);
//         }
//     }
// });

// // --- Apply project checkboxes to all child rows ---
// function apply_project_checkboxes(frm) {
//     (frm.doc.stone_details || []).forEach(row => {
//         if (frm.doc.project_chemical) {
//             row.chemical = 1;
//         }
//         if (frm.doc.project_dry_fitting) {
//             row.dry_fitting = 1;
//         }
//     });
//     frm.refresh_field("stone_details");
// }




// frappe.ui.form.on('Size List Details', {
//     // --- Range -> auto create rows ---
//     range: function(frm, cdt, cdn) {
//         if (frm.__range_generating) return;

//         let row = locals[cdt][cdn];
//         let input = (row.range || '').toString().trim();

//         // Match "1-10" or "01-09"
//         let m = input.match(/^(\d+)\s*[-–]\s*(\d+)$/);
//         if (!m) return;

//         let start = parseInt(m[1], 10);
//         let end   = parseInt(m[2], 10);
//         if (isNaN(start) || isNaN(end) || start > end) return;

//         // Use first row as template
//         let template = frm.doc.stone_details[0];
//         if (!template || !template.stone_code) {
//             frappe.msgprint("Please enter the first row with a valid stone code like AYUSH001.");
//             return;
//         }

//         // Extract prefix + number from stone_code
//         let codeMatch = template.stone_code.match(/^(\D*)(\d+)$/);
//         if (!codeMatch) {
//             frappe.msgprint("Stone Code format must be PREFIX + NUMBER (e.g., AYUSH001).");
//             return;
//         }
//         let prefix = codeMatch[1];
//         let baseNum = parseInt(codeMatch[2], 10);
//         let numWidth = codeMatch[2].length;

//         frm.__range_generating = true;
//         setTimeout(() => {
//             let total_rows = end - start + 1; // e.g. 1-9 → 9 rows total
//             let rows_to_add = total_rows - 1; // minus the first row user already added

//             for (let i = 1; i <= rows_to_add; i++) {
//                 let r = frm.add_child('stone_details');

//                 // Copy everything from template except system fields
//                 Object.keys(template).forEach(f => {
//                     if (f !== "name" && f !== "idx" && f !== "doctype" && f !== "stone_code") {
//                         r[f] = template[f];
//                     }
//                 });

//                 // Auto-increment stone code
//                 r.stone_code = prefix + String(baseNum + i).padStart(numWidth, "0");

//                 // Recalculate volume
//                 calculate_volume(frm, r.doctype, r.name);

//                 // Apply Baps Project controlled checkboxes
//                 if (frm._project_flags?.chemical) r.chemical = 1;
//                 if (frm._project_flags?.dry_fitting) r.dry_fitting = 1;
//             }

//             frm.refresh_field('stone_details');
//             frm.__range_generating = false;
//             update_total_volume(frm);
//         }, 0);
//     },

//     // --- Dimension fields with inch validation (< 12) ---
//     l1: calculate_volume,
//     l2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.l2 >= 12) {
//             frappe.msgprint(('L2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'l2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     b1: calculate_volume,
//     b2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.b2 >= 12) {
//             frappe.msgprint(('B2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'b2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     h1: calculate_volume,
//     h2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.h2 >= 12) {
//             frappe.msgprint(('H2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'h2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },

//     stone_details_remove: function(frm) {
//         update_total_volume(frm);
//     },

//     // --- Chemical / Dry Fitting controlled by Baps Project ---
//     chemical: function(frm, cdt, cdn) {
//         if (frm._project_flags?.chemical) {
//             frappe.model.set_value(cdt, cdn, 'chemical', 1);
//             frappe.msgprint(("Chemical is controlled by the selected Baps Project and cannot be changed."));
//         }
//     },
//     dry_fitting: function(frm, cdt, cdn) {
//         if (frm._project_flags?.dry_fitting) {
//             frappe.model.set_value(cdt, cdn, 'dry_fitting', 1);
//             frappe.msgprint(("Dry Fitting is controlled by the selected Baps Project and cannot be changed."));
//         }
//     },

//     refresh: function(frm) {
//         if (frm && frm.fields_dict && frm.fields_dict.stone_details) {
//             let grid = frm.fields_dict.stone_details.grid;
//             let chem_ro = frm._project_flags?.chemical ? 1 : 0;
//             let dry_ro = frm._project_flags?.dry_fitting ? 1 : 0;
//             grid.update_docfield_property('chemical', 'read_only', chem_ro);
//             grid.update_docfield_property('dry_fitting', 'read_only', dry_ro);
//         }
//     }
// });

// // --- Volume calculation for a single row ---
// function calculate_volume(frm, cdt, cdn) {
//     let row = locals[cdt][cdn];
//     let L = ((row.l1 || 0) * 12) + (row.l2 || 0);
//     let B = ((row.b1 || 0) * 12) + (row.b2 || 0);
//     let H = ((row.h1 || 0) * 12) + (row.h2 || 0);
//     row.volume = ((L * B * H) / 1728).toFixed(2);
//     frm.refresh_field('stone_details');
//     update_total_volume(frm);
// }

// // --- Total volume across all rows ---
// function update_total_volume(frm) {
//     let total = 0;
//     (frm.doc.stone_details || []).forEach(r => {
//         total += flt(r.volume);
//     });
//     frm.set_value('total_volume', total.toFixed(2));
// }

// // --- Helper: set child grid checkboxes read-only based on project flags ---
// function set_child_grid_readonly(frm) {
//     if (!frm.fields_dict || !frm.fields_dict.stone_details) return;
//     let grid = frm.fields_dict.stone_details.grid;
//     let chem_ro = frm._project_flags?.chemical ? 1 : 0;
//     let dry_ro = frm._project_flags?.dry_fitting ? 1 : 0;
//     grid.update_docfield_property('chemical', 'read_only', chem_ro);
//     grid.update_docfield_property('dry_fitting', 'read_only', dry_ro);
// }

// // ============================
// // Parent Doctype: Size List
// // ============================
// frappe.ui.form.on('Size List', {
//     main_part: function(frm) {
//         if (!frm.doc.main_part) frm.set_value('sub_part', '');
//     },
//     sub_part: function(frm) {
//         if (!frm.doc.sub_part) frm.set_value('main_part', '');
//     },
//     refresh: function(frm) {
//         if (frm.doc.baps_project) {
//             load_project_flags(frm);
//         }
//     },
//     baps_project: function(frm) {
//         if (frm.doc.baps_project) {
//             load_project_flags(frm);
//         } else {
//             frm._project_flags = { chemical: 0, dry_fitting: 0 };
//             set_child_grid_readonly(frm);
//         }
//     },
//     stone_details_add: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm._project_flags?.chemical) {
//             frappe.model.set_value(cdt, cdn, 'chemical', 1);
//         }
//         if (frm._project_flags?.dry_fitting) {
//             frappe.model.set_value(cdt, cdn, 'dry_fitting', 1);
//         }
//     }
// });

// // --- Load project flags from linked Baps Project ---
// function load_project_flags(frm) {
//     frappe.db.get_doc("Baps Project", frm.doc.baps_project).then(project => {
//         frm._project_flags = {
//             chemical: project.chemical ? 1 : 0,
//             dry_fitting: project.dry_fitting ? 1 : 0
//         };
//         apply_project_checkboxes(frm);
//         set_child_grid_readonly(frm);
//     });
// }

// // --- Apply project checkboxes to all child rows ---
// function apply_project_checkboxes(frm) {
//     (frm.doc.stone_details || []).forEach(row => {
//         if (frm._project_flags?.chemical) {
//             row.chemical = 1;
//             frappe.model.set_value(row.doctype, row.name, 'chemical', 1);
//         }
//         if (frm._project_flags?.dry_fitting) {
//             row.dry_fitting = 1;
//             frappe.model.set_value(row.doctype, row.name, 'dry_fitting', 1);
//         }
//     });
//     frm.refresh_field("stone_details");
// }









// ============================
// Size List Creation / Size List Details client script
// ============================

// ----------------------------
// Child Doctype: Size List Details
// ----------------------------
frappe.ui.form.on('Size List Details', {

    // --- Range Handler (supports either "1-5" OR "1,8,12" but NOT mixing) ---
    range: function(frm, cdt, cdn) {
    let row = locals[cdt][cdn];
    if (!row || !row.range) return;

    let input = row.range.toString().trim();
    if (!input) return;

    // Disallow mixing comma + dash
    if (input.indexOf('-') !== -1 && input.indexOf(',') !== -1) {
        frappe.show_alert({message: "Invalid input → You cannot mix ranges and comma values", indicator: "red"});
        frappe.model.set_value(cdt, cdn, "range", "");
        return;
    }

    // Parse numbers
    let numbers = [];
    if (input.indexOf('-') !== -1) {
        let parts = input.split('-').map(s => s.trim());
        let start = cint(parts[0]), end = cint(parts[1]);
        if (isNaN(start) || isNaN(end) || start > end) {
            frappe.show_alert({message: "Invalid range → " + input, indicator: "red"});
            return;
        }
        for (let i = start; i <= end; i++) numbers.push(i);
    } else if (input.indexOf(',') !== -1) {
        numbers = input.split(',').map(s => cint(s.trim())).filter(n => !isNaN(n));
    } else {
        let n = cint(input);
        if (!isNaN(n)) numbers = [n];
    }

    numbers = [...new Set(numbers)].sort((a,b) => a-b);
    if (numbers.length === 0) return;

    // First row must have stone_code
    if (!row.stone_code) {
        frappe.show_alert({message: "Please enter Stone Code in the first row before using range", indicator: "red"});
        return;
    }

    let match = row.stone_code.match(/^(.*?)(\d+)$/);
    if (!match) {
        frappe.show_alert({message: "Stone Code must end with numbers, e.g. ABCDE001", indicator: "red"});
        return;
    }

    let prefix = match[1], num_width = match[2].length;

    // Clear range field
    frappe.model.set_value(cdt, cdn, "range", "");

    let duplicate_codes = [];

    numbers.forEach((n, idx) => {
        let stone_code = prefix + String(n).padStart(num_width, "0");

        let exists = frm.doc.stone_details.some(r => r.stone_code === stone_code || r.serial_no === n);
        if (exists) {
            duplicate_codes.push(stone_code);
            return;
        }

        let target_row;
        if (idx === 0) {
            target_row = row;
            target_row.stone_code = stone_code;
            target_row.serial_no = n;
        } else {
            target_row = frm.add_child("stone_details");
            Object.keys(row).forEach(f => {
                if (!["name","idx","doctype","stone_code","range","serial_no"].includes(f)) {
                    target_row[f] = row[f];
                }
            });
            target_row.stone_code = stone_code;
            target_row.serial_no = n;
        }

        calculate_volume(frm, target_row.doctype, target_row.name);
    });

    // Show non-blocking alert for duplicates
    if (duplicate_codes.length) {
        frappe.show_alert({
            message: "Skipped duplicates: " + duplicate_codes.join(", "),
            indicator: "orange"
        });
    }

    frm.refresh_field("stone_details");
},



        // refresh & update totals
    //     frm.refresh_field("stone_details");
    //     update_total_volume(frm);

    //     if (duplicate_codes.length > 0) {
    //         let dupMsg = "Warning: Duplicate Stone Codes detected → " + [...new Set(duplicate_codes)].join(", ");
    //         frappe.show_alert({ message: dupMsg, indicator: "orange" });
    //     }
    // },

    // --- Stone Code handler (backfill sequentially after manual entry) ---
    stone_code: function(frm, cdt, cdn) {
        let row = locals[cdt][cdn];
        if (!row || !row.stone_code) return;

        let match = row.stone_code.match(/^(.*?)(\d+)$/);
        if (!match) {
            frappe.msgprint(__("Stone Code must end with numbers, e.g. ABCDE001"));
            return;
        }

        let prefix = match[1];
        let base_num = cint(match[2]);
        let num_width = match[2].length;
        let next_num = base_num + 1;

        let all = frm.doc.stone_details || [];
        let startIndex = all.findIndex(r => r.name === row.name);
        if (startIndex === -1) return;

        let existing = new Set(all.filter(r => r.stone_code).map(r => r.stone_code));
        let duplicate_codes = [];

        for (let i = startIndex + 1; i < all.length; i++) {
            let r = all[i];
            if (r.stone_code) {
                // if a stone_code is present later, continue sequence from that
                let m = r.stone_code.match(/^(.*?)(\d+)$/);
                if (m && m[1] === prefix) {
                    next_num = cint(m[2]) + 1;
                }
                break;
            }

            let generated = prefix + String(next_num++).padStart(num_width, "0");
            if (existing.has(generated)) {
                duplicate_codes.push(generated);
            }

            // set the child row stone_code
            frappe.model.set_value(r.doctype, r.name, "stone_code", generated);
            existing.add(generated);
            calculate_volume(frm, r.doctype, r.name);
        }

        frm.refresh_field("stone_details");
        update_total_volume(frm);

        if (duplicate_codes.length > 0) {
            let dupMsg = "Warning: Duplicate Stone Codes detected → " + [...new Set(duplicate_codes)].join(", ");
            frappe.show_alert({ message: dupMsg, indicator: "orange" });
        }
    },

    // --- Dimension fields with inch validation (<=12 allowed? you previously wanted <12; kept <12 rule) ---
    l1: calculate_volume,
    l2: function(frm, cdt, cdn) {
        let row = locals[cdt][cdn];
        if (row.l2 >= 12) {
            frappe.msgprint(__('L2 must be less than 12 inches'));
            frappe.model.set_value(cdt, cdn, 'l2', 0);
        }
        calculate_volume(frm, cdt, cdn);
    },
    b1: calculate_volume,
    b2: function(frm, cdt, cdn) {
        let row = locals[cdt][cdn];
        if (row.b2 >= 12) {
            frappe.msgprint(__('B2 must be less than 12 inches'));
            frappe.model.set_value(cdt, cdn, 'b2', 0);
        }
        calculate_volume(frm, cdt, cdn);
    },
    h1: calculate_volume,
    h2: function(frm, cdt, cdn) {
        let row = locals[cdt][cdn];
        if (row.h2 >= 12) {
            frappe.msgprint(__('H2 must be less than 12 inches'));
            frappe.model.set_value(cdt, cdn, 'h2', 0);
        }
        calculate_volume(frm, cdt, cdn);
    },

    stone_details_remove: function(frm) {
        update_total_volume(frm);
    },

    // --- Chemical / Dry Fitting / Polishing controlled by Baps Project ---
    chemical: function(frm, cdt, cdn) {
        if (frm._project_flags?.chemical) {
            frappe.model.set_value(cdt, cdn, 'chemical', 1);
            frappe.msgprint(__("Chemical is controlled by the selected Baps Project and cannot be changed."));
        }
    },
    dry_fitting: function(frm, cdt, cdn) {
        if (frm._project_flags?.dry_fitting) {
            frappe.model.set_value(cdt, cdn, 'dry_fitting', 1);
            frappe.msgprint(__("Dry Fitting is controlled by the selected Baps Project and cannot be changed."));
        }
    },
    polishing: function(frm, cdt, cdn) {
        if (frm._project_flags?.polishing) {
            frappe.model.set_value(cdt, cdn, 'polishing', 1);
            frappe.msgprint(__("Polishing is controlled by the selected Baps Project and cannot be changed."));
        }
    },

    refresh: function(frm) {
        if (frm && frm.fields_dict && frm.fields_dict.stone_details) {
            let grid = frm.fields_dict.stone_details.grid;
            let chem_ro = frm._project_flags?.chemical ? 1 : 0;
            let dry_ro = frm._project_flags?.dry_fitting ? 1 : 0;
            let pol_ro = frm._project_flags?.polishing ? 1 : 0;
            grid.update_docfield_property('chemical', 'read_only', chem_ro);
            grid.update_docfield_property('dry_fitting', 'read_only', dry_ro);
            grid.update_docfield_property('polishing', 'read_only', pol_ro);
        }
    }
});

// --- Volume calculation for a single row ---
function calculate_volume(frm, cdt, cdn) {
    let row = locals[cdt][cdn];
    if (!row) return;
    let L = ((row.l1 || 0) * 12) + (row.l2 || 0);
    let B = ((row.b1 || 0) * 12) + (row.b2 || 0);
    let H = ((row.h1 || 0) * 12) + (row.h2 || 0);
    row.volume = ((L * B * H) / 1728).toFixed(2);
    frm.refresh_field('stone_details');
    update_total_volume(frm);
}

// --- Total volume across all rows ---
function update_total_volume(frm) {
    let total = 0;
    (frm.doc.stone_details || []).forEach(r => {
        total += flt(r.volume);
    });
    frm.set_value('total_volume', total.toFixed(2));
}

// --- Helper: set child grid checkboxes read-only based on project flags ---
function set_child_grid_readonly(frm) {
    if (!frm.fields_dict || !frm.fields_dict.stone_details) return;
    let grid = frm.fields_dict.stone_details.grid;
    let chem_ro = frm._project_flags?.chemical ? 1 : 0;
    let dry_ro = frm._project_flags?.dry_fitting ? 1 : 0;
    let pol_ro = frm._project_flags?.polishing ? 1 : 0;
    grid.update_docfield_property('chemical', 'read_only', chem_ro);
    grid.update_docfield_property('dry_fitting', 'read_only', dry_ro);
    grid.update_docfield_property('polishing', 'read_only', pol_ro);
}

// ============================
// Parent Doctype: Size List Creation
// ============================
frappe.ui.form.on('Size List Creation', {
    main_part: function(frm) {
        if (!frm.doc.main_part) frm.set_value('sub_part', '');
    },
    sub_part: function(frm) {
        if (!frm.doc.sub_part) frm.set_value('main_part', '');
    },
    refresh: function(frm) {
        if (frm.doc.baps_project) {
            load_project_flags(frm);
        }
    },
    baps_project: function(frm) {
        if (frm.doc.baps_project) {
            load_project_flags(frm);
        } else {
            frm._project_flags = { chemical: 0, dry_fitting: 0, polishing: 0 };
            set_child_grid_readonly(frm);
        }
    },
    stone_details_add: function(frm, cdt, cdn) {
        let row = locals[cdt][cdn];
        if (frm._project_flags?.chemical) frappe.model.set_value(cdt, cdn, 'chemical', 1);
        if (frm._project_flags?.dry_fitting) frappe.model.set_value(cdt, cdn, 'dry_fitting', 1);
        if (frm._project_flags?.polishing) frappe.model.set_value(cdt, cdn, 'polishing', 1);
    }
});

// --- Load project flags from linked Baps Project ---
function load_project_flags(frm) {
    if (!frm.doc.baps_project) {
        frm._project_flags = { chemical: 0, dry_fitting: 0, polishing: 0 };
        set_child_grid_readonly(frm);
        return;
    }

    frappe.db.get_doc("Baps Project", frm.doc.baps_project).then(project => {
        frm._project_flags = {
            chemical: project.chemical ? 1 : 0,
            dry_fitting: project.dry_fitting ? 1 : 0,
            polishing: project.polishing ? 1 : 0
        };
        apply_project_checkboxes(frm);
        set_child_grid_readonly(frm);
    });
}

// --- Apply project checkboxes to all child rows ---
function apply_project_checkboxes(frm) {
    (frm.doc.stone_details || []).forEach(row => {
        if (frm._project_flags?.chemical) {
            row.chemical = 1;
            frappe.model.set_value(row.doctype, row.name, 'chemical', 1);
        }
        if (frm._project_flags?.dry_fitting) {
            row.dry_fitting = 1;
            frappe.model.set_value(row.doctype, row.name, 'dry_fitting', 1);
        }
        if (frm._project_flags?.polishing) {
            row.polishing = 1;
            frappe.model.set_value(row.doctype, row.name, 'polishing', 1);
        }
    });
    frm.refresh_field("stone_details");
}

// frappe.ui.form.on("Size List", {
//     // when main part changes
//     main_part: function(frm) {
//         frm.set_query("sub_part", function() {
//             return {
//                 filters: {
//                     main_part: frm.doc.main_part
//                 }
//             };
//         });

//         // clear sub_part if it's not matching
//         if (frm.doc.sub_part) {
//             frappe.db.get_value("Sub Part", frm.doc.sub_part, "main_part", function(r) {
//                 if (r && r.main_part !== frm.doc.main_part) {
//                     frm.set_value("sub_part", null);
//                 }
//             });
//         }
//     },


frappe.ui.form.on("Size List Creation", {
    main_part: function(frm) {
        // restrict sub_part based on main_part
        frm.set_query("sub_part", function() {
            if (!frm.doc.main_part) {
                frappe.throw("Please select Main Part before choosing a Sub Part.");
            }
            return {
                filters: {
                    main_part: frm.doc.main_part
                }
            };
        });

        // clear sub_part if mismatch
        if (frm.doc.sub_part) {
            frappe.db.get_value("Sub Part", frm.doc.sub_part, "main_part", function(r) {
                if (r && r.main_part !== frm.doc.main_part) {
                    frm.set_value("sub_part", null);
                }
            });
        }
    },

    validate: function(frm) {
        if (!frm.doc.main_part && frm.doc.sub_part) {
            frappe.throw("You cannot add a Sub Part without selecting a Main Part.");
        }
    }
});






    // // when sub part changes
    // sub_part: function(frm) {
    //     if (frm.doc.sub_part) {
    //         frappe.db.get_value("Sub Part", frm.doc.sub_part, "main_part", function(r) {
    //             if (r && r.main_part) {
    //                 frm.set_value("main_part", r.main_part);
    //             }
    //         });
    //     }
    // }






// frappe.ui.form.on('Size List Details', {
//     // --- Range -> auto create rows ---
//     range: function(frm, cdt, cdn) {
//         if (frm.__range_generating) return;

//         let row = locals[cdt][cdn];
//         let input = (row.range || '').toString().trim();

//         // Match "1-10" or "01-09"
//         let m = input.match(/^(\d+)\s*[-–]\s*(\d+)$/);
//         if (!m) return;

//         let start = parseInt(m[1], 10);
//         let end   = parseInt(m[2], 10);
//         if (isNaN(start) || isNaN(end) || start > end) return;

//         // Use current row as template
//         let template = Object.assign({}, row);

//         // Extract prefix + number from stone_code if it exists
//         let codeMatch = null;
//         let prefix = "";
//         let baseNum = 0;
//         let numWidth = 0;

//         if (template.stone_code) {
//             codeMatch = template.stone_code.match(/^(\D*)(\d+)$/);
//             if (codeMatch) {
//                 prefix = codeMatch[1];
//                 baseNum = parseInt(codeMatch[2], 10);
//                 numWidth = codeMatch[2].length;
//             }
//         }

//         frm.__range_generating = true;
//         setTimeout(() => {
//             let total_rows = end - start + 1;

//             // Clear existing rows to prevent duplicates
//             frm.clear_table('stone_details');
//             frm.refresh_field('stone_details');

//             for (let i = 0; i < total_rows; i++) {
//                 let r = frm.add_child('stone_details');

//                 // Copy all fields from template except system fields & stone_code
//                 Object.keys(template).forEach(f => {
//                     if (f !== "name" && f !== "idx" && f !== "doctype" && f !== "stone_code") {
//                         r[f] = template[f];
//                     }
//                 });

//                 // Auto-increment stone_code only if it exists
//                 if (codeMatch) {
//                     r.stone_code = prefix + String(baseNum + i).padStart(numWidth, "0");
//                 } else {
//                     r.stone_code = ""; // keep empty if not filled
//                 }

//                 // Recalculate volume
//                 calculate_volume(frm, r.doctype, r.name);

//                 // Apply Baps Project controlled checkboxes
//                 if (frm._project_flags?.chemical) r.chemical = 1;
//                 if (frm._project_flags?.dry_fitting) r.dry_fitting = 1;
//             }

//             frm.refresh_field('stone_details');
//             frm.__range_generating = false;
//             update_total_volume(frm);
//         }, 0);
//     },

//     // --- Dimension fields with inch validation (< 12) ---
//     l1: calculate_volume,
//     l2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.l2 >= 12) {
//             frappe.msgprint(('L2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'l2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     b1: calculate_volume,
//     b2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.b2 >= 12) {
//             frappe.msgprint(('B2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'b2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     h1: calculate_volume,
//     h2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.h2 >= 12) {
//             frappe.msgprint(('H2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'h2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },

//     stone_details_remove: function(frm) {
//         update_total_volume(frm);
//     },

//     // --- Chemical / Dry Fitting controlled by Baps Project ---
//     chemical: function(frm, cdt, cdn) {
//         if (frm._project_flags?.chemical) {
//             frappe.model.set_value(cdt, cdn, 'chemical', 1);
//             frappe.msgprint(("Chemical is controlled by the selected Baps Project and cannot be changed."));
//         }
//     },
//     dry_fitting: function(frm, cdt, cdn) {
//         if (frm._project_flags?.dry_fitting) {
//             frappe.model.set_value(cdt, cdn, 'dry_fitting', 1);
//             frappe.msgprint(("Dry Fitting is controlled by the selected Baps Project and cannot be changed."));
//         }
//     },

//     refresh: function(frm) {
//         if (frm && frm.fields_dict && frm.fields_dict.stone_details) {
//             let grid = frm.fields_dict.stone_details.grid;
//             let chem_ro = frm._project_flags?.chemical ? 1 : 0;
//             let dry_ro = frm._project_flags?.dry_fitting ? 1 : 0;
//             grid.update_docfield_property('chemical', 'read_only', chem_ro);
//             grid.update_docfield_property('dry_fitting', 'read_only', dry_ro);
//         }
//     }
// });

// // --- Volume calculation for a single row ---
// function calculate_volume(frm, cdt, cdn) {
//     let row = locals[cdt][cdn];
//     let L = ((row.l1 || 0) * 12) + (row.l2 || 0);
//     let B = ((row.b1 || 0) * 12) + (row.b2 || 0);
//     let H = ((row.h1 || 0) * 12) + (row.h2 || 0);
//     row.volume = ((L * B * H) / 1728).toFixed(2);
//     frm.refresh_field('stone_details');
//     update_total_volume(frm);
// }

// // --- Total volume across all rows ---
// function update_total_volume(frm) {
//     let total = 0;
//     (frm.doc.stone_details || []).forEach(r => {
//         total += flt(r.volume);
//     });
//     frm.set_value('total_volume', total.toFixed(2));
// }

// // --- Helper: set child grid checkboxes read-only based on project flags ---
// function set_child_grid_readonly(frm) {
//     if (!frm.fields_dict || !frm.fields_dict.stone_details) return;
//     let grid = frm.fields_dict.stone_details.grid;
//     let chem_ro = frm._project_flags?.chemical ? 1 : 0;
//     let dry_ro = frm._project_flags?.dry_fitting ? 1 : 0;
//     grid.update_docfield_property('chemical', 'read_only', chem_ro);
//     grid.update_docfield_property('dry_fitting', 'read_only', dry_ro);
// }

// // ============================
// // Parent Doctype: Size List
// // ============================
// frappe.ui.form.on('Size List', {
//     main_part: function(frm) {
//         if (!frm.doc.main_part) frm.set_value('sub_part', '');
//     },
//     sub_part: function(frm) {
//         if (!frm.doc.sub_part) frm.set_value('main_part', '');
//     },
//     refresh: function(frm) {
//         if (frm.doc.baps_project) {
//             load_project_flags(frm);
//         }
//     },
//     baps_project: function(frm) {
//         if (frm.doc.baps_project) {
//             load_project_flags(frm);
//         } else {
//             frm._project_flags = { chemical: 0, dry_fitting: 0 };
//             set_child_grid_readonly(frm);
//         }
//     },
//     stone_details_add: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm._project_flags?.chemical) {
//             frappe.model.set_value(cdt, cdn, 'chemical', 1);
//         }
//         if (frm._project_flags?.dry_fitting) {
//             frappe.model.set_value(cdt, cdn, 'dry_fitting', 1);
//         }
//     }
// });

// // --- Load project flags from linked Baps Project ---
// function load_project_flags(frm) {
//     frappe.db.get_doc("Baps Project", frm.doc.baps_project).then(project => {
//         frm._project_flags = {
//             chemical: project.chemical ? 1 : 0,
//             dry_fitting: project.dry_fitting ? 1 : 0
//         };
//         apply_project_checkboxes(frm);
//         set_child_grid_readonly(frm);
//     });
// }

// // --- Apply project checkboxes to all child rows ---
// function apply_project_checkboxes(frm) {
//     (frm.doc.stone_details || []).forEach(row => {
//         if (frm._project_flags?.chemical) {
//             row.chemical = 1;
//             frappe.model.set_value(row.doctype, row.name, 'chemical', 1);
//         }
//         if (frm._project_flags?.dry_fitting) {
//             row.dry_fitting = 1;
//             frappe.model.set_value(row.doctype, row.name, 'dry_fitting', 1);
//         }
//     });
//     frm.refresh_field("stone_details");
// }


// // ============================
// // Child Doctype: Size List Details
// // ============================
// frappe.ui.form.on('Size List Details', {
//     // --- Range -> auto create rows ---
//     range: function(frm, cdt, cdn) {
//         if (frm.__range_generating) return;

//         let row = locals[cdt][cdn];
//         let input = (row.range || '').toString().trim();

//         let m = input.match(/^(\d+)\s*[-–]\s*(\d+)$/);
//         if (!m) return;

//         let start = parseInt(m[1], 10);
//         let end   = parseInt(m[2], 10);
//         if (isNaN(start) || isNaN(end) || start > end) return;

//         const width = Math.max(m[1].length, m[2].length);

//         // Save template row values (the first row user filled)
//         let template = Object.assign({}, row);

//         frm.__range_generating = true;
//         setTimeout(() => {
//             frm.clear_table('stone_details');

//             for (let i = start; i <= end; i++) {
//                 let r = frm.add_child('stone_details');

//                 // Copy all fields from template row
//                 Object.keys(template).forEach(f => {
//                     if (f !== "name" && f !== "idx" && f !== "doctype") {
//                         r[f] = template[f];
//                     }
//                 });

//                 // Update range
//                 r.range = i.toString().padStart(width, '0');

//                 // Auto increment stone code if format matches (prefix + digits)
//                 if (template.stone_code) {
//                     let codeMatch = template.stone_code.match(/^(\D*)(\d+)$/); 
//                     if (codeMatch) {
//                         let prefix = codeMatch[1];
//                         let num = parseInt(codeMatch[2], 10);
//                         let numWidth = codeMatch[2].length;
//                         r.stone_code = prefix + (num + (i - start)).toString().padStart(numWidth, '0');
//                     }
//                 }

//                 // Copy same dimensions for all rows
//                 r.l1 = template.l1;
//                 r.l2 = template.l2;
//                 r.b1 = template.b1;
//                 r.b2 = template.b2;
//                 r.h1 = template.h1;
//                 r.h2 = template.h2;

//                 // Recalculate volume for each row
//                 calculate_volume(frm, r.doctype, r.name);
//             }

//             frm.refresh_field('stone_details');
//             frm.__range_generating = false;
//             update_total_volume(frm);
//         }, 0);
//     },

//     // --- Dimension fields with inch validation (< 12) ---
//     l1: calculate_volume,
//     l2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.l2 >= 12) {
//             frappe.msgprint(('L2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'l2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     b1: calculate_volume,
//     b2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.b2 >= 12) {
//             frappe.msgprint(('B2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'b2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },
//     h1: calculate_volume,
//     h2: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (row.h2 >= 12) {
//             frappe.msgprint(('H2 must be less than 12 inches'));
//             frappe.model.set_value(cdt, cdn, 'h2', 0);
//         }
//         calculate_volume(frm, cdt, cdn);
//     },

//     stone_details_remove: function(frm) {
//         update_total_volume(frm);
//     },

//     // --- Chemical / Dry Fitting controlled by Baps Project ---
//     chemical: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm.doc.project_chemical) {
//             row.chemical = 1;
//             frm.refresh_field("stone_details");
//             frappe.msgprint(("Chemical is controlled by Baps Project and cannot be changed."));
//         }
//     },
//     dry_fitting: function(frm, cdt, cdn) {
//         let row = locals[cdt][cdn];
//         if (frm.doc.project_dry_fitting) {
//             row.dry_fitting = 1;
//             frm.refresh_field("stone_details");
//             frappe.msgprint(("Dry Fitting is controlled by Baps Project and cannot be changed."));
//         }
//     }
// });

// // --- Volume calculation for a single row ---
// function calculate_volume(frm, cdt, cdn) {
//     let row = locals[cdt][cdn];

//     // Convert feet+inches → inches
//     let L = ((row.l1 || 0) * 12) + (row.l2 || 0);
//     let B = ((row.b1 || 0) * 12) + (row.b2 || 0);
//     let H = ((row.h1 || 0) * 12) + (row.h2 || 0);

//     // Volume in cubic feet
//     row.volume = ((L * B * H) / 1728).toFixed(2);

//     frm.refresh_field('stone_details');
//     update_total_volume(frm);
// }

// // --- Total volume across all rows ---
// function update_total_volume(frm) {
//     let total = 0;
//     (frm.doc.stone_details || []).forEach(r => {
//         total += flt(r.volume);
//     });
//     frm.set_value('total_volume', total.toFixed(2));
// }

// // ============================
// // Parent Doctype: Size List
// // ============================
// frappe.ui.form.on('Size List', {
//     main_part: function(frm) {
//         if (!frm.doc.main_part) {
//             frm.set_value('sub_part', '');
//         }
//     },
//     sub_part: function(frm) {
//         if (!frm.doc.sub_part) {
//             frm.set_value('main_part', '');
//         }
//     },
//     refresh: function(frm) {
//         apply_project_checkboxes(frm);
//     },
//     baps_project: function(frm) {
//         if (frm.doc.baps_project) {
//             frappe.db.get_doc("Baps Project", frm.doc.baps_project).then(project => {
//                 frm.doc.project_chemical = project.chemical;
//                 frm.doc.project_dry_fitting = project.dry_fitting;
//                 apply_project_checkboxes(frm);
//             });
//         } else {
//             frm.doc.project_chemical = 0;
//             frm.doc.project_dry_fitting = 0;
//             apply_project_checkboxes(frm);
//         }
//     }
// });

// // --- Apply project checkboxes to all child rows ---
// function apply_project_checkboxes(frm) {
//     (frm.doc.stone_details || []).forEach(row => {
//         if (frm.doc.project_chemical) {
//             row.chemical = 1;
//         }
//         if (frm.doc.project_dry_fitting) {
//             row.dry_fitting = 1;
//         }
//     });
//     frm.refresh_field("stone_details");
// }