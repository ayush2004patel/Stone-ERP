// Copyright (c) 2025, Dharmesh Rathod and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Baps Project", {
// 	refresh(frm) {

// 	},
// });





// Client Script on parent doctype (Baps Project)
// ensures Sub Process dropdown in child rows shows only sub-processes for selected Process







// frappe.ui.form.on('Baps Project', {
//     refresh: function(frm) {
//         const grid_fieldname = 'process_details'; // change if your table fieldname differs
//         if (!frm.fields_dict[grid_fieldname]) return;

//         // define get_query for the child-grid "sub_process" field
//         frm.fields_dict[grid_fieldname].grid.get_field('sub_process').get_query = function(doc, cdt, cdn) {
//             const row = (locals[cdt] || {})[cdn] || {};
//             // if no process chosen show no rows (or remove this condition to show all)
//             if (!row.process) {
//                 return {
//                     filters: { 'parent_process': '' } // returns empty set
//                 };
//             }
//             return {
//                 filters: {
//                     'parent_process': row.process
//                 }
//             };
//         };
//     }
// });

// // also clear sub_process when process changes (so old value doesn't remain)
// frappe.ui.form.on('Project Process Detail', {
//     process: function(frm, cdt, cdn) {
//         // clear previously selected sub_process when user changes the process
//         frappe.model.set_value(cdt, cdn, 'sub_process', '');
//         // refresh grid so the sub_process dropdown uses new get_query
//         if (frm.fields_dict['process_details']) {
//             frm.fields_dict['process_details'].grid.refresh();
//         }
//     }
// });





frappe.ui.form.on('Baps Project', {
    refresh: function(frm) {
        frm.fields_dict['process_details'].grid.get_field('sub_process').get_query = function(doc, cdt, cdn) {
            let row = locals[cdt][cdn];
            return {
                filters: { parent_process: row.processes }
            };
        };
    }
});

frappe.ui.form.on('Project Process Detail', {
    processes: function(frm, cdt, cdn) {
        frappe.model.set_value(cdt, cdn, 'sub_process', '');
    }
});
