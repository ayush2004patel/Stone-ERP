# Copyright (c) 2025, Dharmesh Rathod and contributors
# For license information, please see license.txt

# import frappe
# from frappe.model.document import Document


# class TransportationSender(Document):
# 	pass

# apps/baps/baps/baps/doctype/transportation_sender/transportation_sender.py

import frappe
import json
from frappe import _
from frappe.model.document import Document


class TransportationSender(Document):
    pass


@frappe.whitelist()
def get_blocks_for_project(project):
    """
    Fetch all unique block numbers from Block Selections linked to the given Baps Project.
    """
    block_numbers = []

    block_selections = frappe.get_all(
        "Block Selection",
        filters={"baps_project": project},
        fields=["name"]
    )

    for bs in block_selections:
        details = frappe.get_all(
            "Block Selection Detail",
            filters={
                "parent": bs.name,
                "parenttype": "Block Selection"
            },
            fields=["block_number"]
        )
        for d in details:
            if d.block_number:
                block_numbers.append({"block_number": d.block_number})

    # Deduplicate
    seen = set()
    unique_blocks = []
    for block in block_numbers:
        if block["block_number"] not in seen:
            seen.add(block["block_number"])
            unique_blocks.append(block)

    return unique_blocks


@frappe.whitelist()
def add_blocks_to_table(sender_name, blocks):
    """
    Add selected blocks to the transport_material_type child table.
    Now includes material_number.
    """
    if isinstance(blocks, str):
        try:
            blocks = json.loads(blocks)
        except json.JSONDecodeError:
            frappe.throw(_("Invalid format for blocks. Expected a valid JSON list."))

    if not isinstance(blocks, list):
        frappe.throw(_("Blocks must be a list of block data."))

    doc = frappe.get_doc("Transportation Sender", sender_name)
    existing = [row.block_number for row in doc.transport_material_type]

    added_count = 0
    for block_data in blocks:
        block_num = block_data.get("block_number")
        if not block_num or block_num in existing:
            continue

        # Append with material_number
        doc.append("transport_material_type", {
            "project": block_data.get("project"),
            "material_type": block_data.get("material_type"),
            "block_number": block_num,
            "material_number": block_num  # ✅ Set material_number
        })
        added_count += 1

    doc.save(ignore_permissions=True)
    frappe.msgprint(_(f"{added_count} block(s) added to material table."))