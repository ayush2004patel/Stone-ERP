// Copyright (c) 2025, Dharmesh Rathod and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Transportation Sender", {
// 	refresh(frm) {

// 	},
// });
// apps/baps/baps/baps/doctype/transportation_sender/transportation_sender.js

// transportation_sender.js

frappe.ui.form.on('Transportation Sender', {
    refresh: function (frm) {
        // Optional: You can add custom buttons here if needed
    },

    // Trigger when "Show Items" button is clicked
    show_items: function (frm) {
        show_items_dialog(frm);
    }
});

function show_items_dialog(frm) {
    // Create the dialog
    const d = new frappe.ui.Dialog({
        title: 'Select Blocks to Add',
        fields: [
            {
                label: 'Baps Project',
                fieldname: 'baps_project',
                fieldtype: 'Link',
                options: 'Baps Project',
                reqd: true,
                default: frm.doc.baps_project
            },
            {
                label: 'Material Type',
                fieldname: 'material_type',
                fieldtype: 'Link',
                options: 'Stone Type',
                reqd: true,
                default: frm.doc.material_type
            },
            {
                fieldtype: 'Section Break',
                label: 'Available Blocks'
            },
            {
                fieldname: 'block_items',
                fieldtype: 'HTML'
            }
        ],
        primary_action_label: 'Add Selected',
        primary_action: function () {
            const values = d.get_values();
            const selected_blocks = [];

            // ✅ Only get CHECKED checkboxes
            const checkedBoxes = document.querySelectorAll('input[data-block-checkbox="1"]:checked');
            
            checkedBoxes.forEach((cb) => {
                selected_blocks.push({
                    block_number: cb.dataset.block,
                    project: values.baps_project,
                    material_type: values.material_type
                });
            });

            if (selected_blocks.length === 0) {
                frappe.msgprint(__('Please select at least one block.'));
                return;
            }

            // Call server method to add blocks
            frappe.call({
                method: 'baps.baps.doctype.transportation_sender.transportation_sender.add_blocks_to_table',
                args: {
                    sender_name: frm.doc.name,
                    blocks: selected_blocks  // This is an array of objects
                },
                callback: function (r) {
                    if (!r.exc) {
                        frappe.show_alert({
                            message: __('Blocks added successfully'),
                            indicator: 'green'
                        });
                        frm.reload_doc();  // Reload to reflect changes
                        d.hide();         // Close dialog
                    } else {
                        frappe.msgprint(__('Error adding blocks. Please try again.'));
                    }
                }
            });
        }
    });

    // Update block list when project or material type changes
    d.fields_dict.baps_project.df.onchange = d.fields_dict.material_type.df.onchange = () => {
        update_block_list(d, frm);
    };

    // Initial load of block list
    update_block_list(d, frm);

    // Show the dialog
    d.show();
}

function update_block_list(dialog, frm) {
    const values = dialog.get_values();
    const project = values?.baps_project;

    if (!project) {
        dialog.fields_dict.block_items.$wrapper.html(
            '<p style="color: var(--text-color-light); font-style: italic;">Select a Baps Project to load blocks.</p>'
        );
        return;
    }

    frappe.call({
        method: 'baps.baps.doctype.transportation_sender.transportation_sender.get_blocks_for_project',
        args: {
            project: project
        },
        callback: function (r) {
            if (r.message && Array.isArray(r.message) && r.message.length > 0) {
                let html = `
                    <div style="max-height: 300px; overflow-y: auto; border: 1px solid #d1d8dd; border-radius: 5px; padding: 8px; background: #fafbfc;">
                        <p style="margin: 0 0 8px; font-weight: 500; color: var(--text-color);">Select blocks:</p>
                `;

                r.message.forEach(block => {
                    const blockNum = block.block_number || 'Unknown';
                    html += `
                        <div class="checkbox" style="margin: 4px 0;">
                            <label style="font-size: 14px; color: var(--text-color);">
                                <input type="checkbox" 
                                       data-block-checkbox="1" 
                                       data-block="${blockNum}" 
                                       style="margin-right: 6px;" />
                                ${blockNum}
                            </label>
                        </div>
                    `;
                });

                html += `</div>`;
                dialog.fields_dict.block_items.$wrapper.html(html);
            } else {
                dialog.fields_dict.block_items.$wrapper.html(
                    '<p style="color: #7d8588; font-style: italic;">No blocks found for this project.</p>'
                );
            }
        }
    });
}