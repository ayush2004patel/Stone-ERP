import frappe
from frappe.model.document import Document

class CuttingExecution(Document):
    pass
