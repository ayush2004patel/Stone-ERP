# Copyright (c) 2025, Tirthan Shah and contributors
# For license information, please see license.txt

# # import frappe
# from frappe.model.document import Document


# class GatePassBookNo(Document):
# 	pass

# apps/baps/baps/doctype/gate_pass_bookno/gate_pass_bookno.py

import frappe
from frappe import _
from frappe.model.document import Document


class GatePassBookNo(Document):
    def after_insert(self):
        """Called after Gate Pass BookNo is created"""
        frappe.msgprint(_("Starting to create Gate Pass No records..."))
        self.create_gate_pass_numbers()

    def create_gate_pass_numbers(self):
        # Check if already created
        existing = frappe.db.get_all(
            "Gate Pass No",
            filters={"gate_pass_book_no": self.name},
            limit=1
        )
        if existing:
            frappe.msgprint(_("Gate Pass No records already exist. Skipping."))
            return

        created = 0
        failed = 0

        for i in range(1, 51):
            # Use unique name: GPBNO-0001-01
            name = f"{self.name}-{str(i).zfill(2)}"  # e.g., GPBNO-0001-01

            # Skip if name exists (even in trash)
            if frappe.db.exists("Gate Pass No", name):
                continue

            try:
                doc = frappe.new_doc("Gate Pass No")
                doc.name = name
                doc.gate_pass_no = str(i)
                doc.gate_pass_book_no = self.name
                # gp_book_no will be auto-fetched via fetch_from

                # Insert with safe flags (v15+ compatible)
                doc.insert(
                    ignore_permissions=True,
                    # ignore_naming_rule=True,  # ❌ Remove this line — it's the culprit!
                )
                created += 1

            except Exception as e:
                frappe.log_error(
                    f"Gate Pass No Create Error: {str(e)}\nBook: {self.name}, Num: {i}",
                    "Gate Pass Creation Failed"
                )
                failed += 1

        frappe.msgprint(_(
            f"Gate Pass No: Created={created}, Failed={failed}<br>Linked to: <b>{self.name}</b>"
        ))