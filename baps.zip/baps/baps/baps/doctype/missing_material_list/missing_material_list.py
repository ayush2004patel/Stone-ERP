# Copyright (c) 2025, Tirthan Shah and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class MissingMaterialList(Document):
	pass
