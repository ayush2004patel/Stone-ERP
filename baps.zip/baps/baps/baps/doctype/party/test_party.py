# Copyright (c) 2025, Tirthan Shah and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestParty(FrappeTestCase):
	pass
